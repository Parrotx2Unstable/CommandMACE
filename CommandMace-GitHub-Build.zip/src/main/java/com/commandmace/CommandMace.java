package com.commandmace;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LightningStrike;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.LocalDate;
import java.util.*;

public final class CommandMace extends JavaPlugin implements Listener {
    private NamespacedKey maceKey, killsKey;
    private static final int MODEL_DATA = 10001;
    private static final double DAILY_HEART_CAP = 40.0; // +20 hearts
    private static final double HEAL_AMOUNT = 4.0; // 2 hearts
    private final Map<UUID, LocalDate> checkedDates = new HashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        maceKey = new NamespacedKey(this, "command_mace");
        killsKey = new NamespacedKey(this, "mace_kills");
        Bukkit.getPluginManager().registerEvents(this, this);
        registerRecipe();
        for (Player p : Bukkit.getOnlinePlayers()) refreshDailyHearts(p);
        getLogger().info("CommandMace enabled.");
    }

    private void registerRecipe() {
        ItemStack result = createMace();
        ShapedRecipe recipe = new ShapedRecipe(new NamespacedKey(this, "command_mace_recipe"), result);
        recipe.shape("H", "C", "B");
        recipe.setIngredient('H', Material.HEAVY_CORE);
        recipe.setIngredient('C', Material.COMMAND_BLOCK);
        recipe.setIngredient('B', Material.BREEZE_ROD);
        Bukkit.addRecipe(recipe);
    }

    private ItemStack createMace() {
        ItemStack item = new ItemStack(Material.MACE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§6§lCommand Mace");
        meta.setCustomModelData(MODEL_DATA);
        meta.getPersistentDataContainer().set(maceKey, PersistentDataType.BYTE, (byte) 1);
        meta.getPersistentDataContainer().set(killsKey, PersistentDataType.INTEGER, 0);
        meta.addEnchant(Enchantment.DENSITY, 5, true);
        meta.addEnchant(Enchantment.BREACH, 4, true);
        meta.addEnchant(Enchantment.WIND_BURST, 3, true);
        meta.addEnchant(Enchantment.UNBREAKING, 3, true);
        meta.addEnchant(Enchantment.MENDING, 1, true);
        meta.setLore(Arrays.asList("§7A weapon forged from commands.", "§cShield Piercing", "§aSmash hit: +2 hearts healed", "§dPlayer kills: +1 heart daily (max +20)", "§eKills with this mace: §f0", "§6Bonus smash damage: §f+0"));
        item.setItemMeta(meta);
        return item;
    }

    private boolean isCommandMace(ItemStack item) {
        if (item == null || item.getType() != Material.MACE || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(maceKey, PersistentDataType.BYTE);
    }

    private int getKills(ItemStack item) {
        return item.getItemMeta().getPersistentDataContainer().getOrDefault(killsKey, PersistentDataType.INTEGER, 0);
    }

    private void updateLore(ItemStack item, int kills) {
        ItemMeta meta = item.getItemMeta();
        List<String> lore = new ArrayList<>();
        lore.add("§7A weapon forged from commands.");
        lore.add("§cShield Piercing");
        lore.add("§aSmash hit: +2 hearts healed");
        lore.add("§dPlayer kills: +1 heart daily (max +20)");
        lore.add("§eKills with this mace: §f" + kills);
        lore.add("§6Bonus smash damage: §f+" + (kills * 1.0));
        meta.setLore(lore);
        item.setItemMeta(meta);
    }

    private void refreshDailyHearts(Player p) {
        String today = LocalDate.now().toString();
        String savedDate = getConfig().getString("players." + p.getUniqueId() + ".heart-date", "");
        if (!today.equals(savedDate)) {
            getConfig().set("players." + p.getUniqueId() + ".heart-date", today);
            getConfig().set("players." + p.getUniqueId() + ".daily-hearts", 0);
            saveConfig();
        }
        int hearts = getConfig().getInt("players." + p.getUniqueId() + ".daily-hearts", 0);
        setMaxHealth(p, 20.0 + Math.min(20, hearts) * 2.0);
        checkedDates.put(p.getUniqueId(), LocalDate.now());
    }

    private void setMaxHealth(Player p, double value) {
        AttributeInstance attr = p.getAttribute(Attribute.MAX_HEALTH);
        if (attr != null) {
            attr.setBaseValue(value);
            if (p.getHealth() > value) p.setHealth(value);
        }
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) { refreshDailyHearts(e.getPlayer()); }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSmash(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player attacker)) return;
        Entity target = e.getEntity();
        ItemStack held = attacker.getInventory().getItemInMainHand();
        if (!isCommandMace(held)) return;

        // A true mace smash requires the attacker to be airborne and falling when the damage event fires.
        boolean smash = !attacker.isOnGround() && attacker.getFallDistance() > 0.0f;
        if (!smash) return;

        int kills = getKills(held);
        e.setDamage(e.getDamage() + kills * 1.0); // +0.5 heart per player kill

        // Make shield blocking ineffective for this smash.
        if (target instanceof Player victim && victim.isBlocking()) {
            victim.setCooldown(Material.SHIELD, 100);
            victim.setCooldown(Material.SHIELD, 100);
        }

        target.getWorld().strikeLightningEffect(target.getLocation());
        double healed = Math.min(HEAL_AMOUNT, attacker.getMaxHealth() - attacker.getHealth());
        if (healed > 0) attacker.setHealth(Math.min(attacker.getMaxHealth(), attacker.getHealth() + healed));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerKill(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();
        if (killer == null) return;
        ItemStack held = killer.getInventory().getItemInMainHand();
        if (!isCommandMace(held)) return;

        int kills = getKills(held) + 1;
        ItemMeta meta = held.getItemMeta();
        meta.getPersistentDataContainer().set(killsKey, PersistentDataType.INTEGER, kills);
        held.setItemMeta(meta);
        updateLore(held, kills);

        refreshDailyHearts(killer);
        String path = "players." + killer.getUniqueId() + ".daily-hearts";
        int hearts = getConfig().getInt(path, 0);
        if (hearts < 20) {
            hearts++;
            getConfig().set(path, hearts);
            saveConfig();
            setMaxHealth(killer, 20.0 + hearts * 2.0);
            killer.sendMessage("§dCommand Mace: §a+1 heart! §7(" + hearts + "/20 today)");
        } else {
            killer.sendMessage("§dCommand Mace: §eDaily heart limit reached (20/20).");
        }
        killer.sendMessage("§6Command Mace strengthened: §f+" + kills + " damage on smash hits.");
    }

    @EventHandler public void onPrepareCraft(PrepareItemCraftEvent e) {
        // Recipe result already carries the custom item metadata.
        if (e.getRecipe() == null) return;
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("commandmace")) return false;
        if (args.length >= 1 && args[0].equalsIgnoreCase("give")) {
            if (!sender.hasPermission("commandmace.admin")) {
                sender.sendMessage("§cYou don't have permission.");
                return true;
            }
            Player target;
            if (args.length >= 2) target = Bukkit.getPlayerExact(args[1]);
            else if (sender instanceof Player p) target = p;
            else { sender.sendMessage("Use /commandmace give <player>"); return true; }
            if (target == null) { sender.sendMessage("§cPlayer not found. Use /commandmace give <player>"); return true; }
            target.getInventory().addItem(createMace());
            sender.sendMessage("§aGave Command Mace to " + target.getName());
            return true;
        }
        sender.sendMessage("§e/commandmace give <player>");
        return true;
    }
}
