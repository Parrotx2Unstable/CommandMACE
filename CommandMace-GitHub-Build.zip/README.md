# Command Mace — Minecraft Java 1.21.11

## Contents
- `CommandMace-1.21.11/`: Maven source project for the Paper plugin.
- `CommandMace-Resource-Pack.zip`: custom model texture pack with a black handle.

## Build the plugin
Requires Java 21 and Maven:
1. Open a terminal in `CommandMace-1.21.11`.
2. Run `mvn package`.
3. Copy `target/command-mace-1.0.0.jar` into your Paper server's `plugins` folder.
4. Restart the server.

The source targets Paper API `1.21.11-R0.1-SNAPSHOT`. If that exact API snapshot is not yet published by your repository mirror, use the latest available Paper 1.21.11 API version in `pom.xml`.

## Install the resource pack
Import `CommandMace-Resource-Pack.zip` into Minecraft's Resource Packs and enable it. The model uses custom model data `10001`, which the plugin applies to the item. For multiplayer, upload the ZIP to a direct-download host and set the server resource-pack URL.

## Features
- Shaped recipe: Heavy Core above Command Block above Breeze Rod.
- Forced enchants: Density V, Breach IV, Wind Burst III, Unbreaking III, Mending I.
- Only falling smash hits trigger healing, bonus damage, and lightning visual effect.
- Successful smash heals 2 hearts (4 health points).
- Each player kill with the mace permanently increases its smash damage by 1 health point (half a heart).
- Player kills grant +1 max-health heart per day, capped at +20 bonus hearts; daily heart count resets based on the server's local date.
- `/commandmace give <player>` (op permission).

## Notes / compatibility
This is a source project, not a precompiled JAR. Compile it with Maven on a machine with Java 21 and repository access. Paper/Bukkit event timing varies by version; test shield bypass and smash detection on a staging server before using it in a live competitive SMP.

## Build automatically on GitHub (no Maven installation on your PC)
1. Sign in to GitHub and create a new repository.
2. Extract this ZIP and upload the contents of this folder into the repository, including `.github/workflows/build.yml`.
3. Open the repository's Actions tab.
4. Select Build Command Mace Plugin and click Run workflow (or push a commit to main).
5. Open the completed run, find Artifacts, and download `command-mace-plugin`. Extract it to get `command-mace-1.0.0.jar`.

If the build fails, share the workflow error log so the source can be fixed.
